import { Header } from "@/components/femibion/header"
import { Hero } from "@/components/femibion/hero"
import { ProductCards } from "@/components/femibion/product-cards"
import { PregnancySlider } from "@/components/femibion/pregnancy-slider"
import { OrderForm } from "@/components/femibion/order-form"
import { Footer } from "@/components/femibion/footer"

export default function FemibionLandingPage() {
  return (
    <div className="min-h-screen">
      <Header />
      <main>
        <Hero />
        <ProductCards />
        <PregnancySlider />
        <OrderForm />
      </main>
      <Footer />
    </div>
  )
}
