"use client"

import { useState } from "react"
import { cn } from "@/lib/utils"

const languages = [
  { code: "GE", label: "ქარ" },
  { code: "EN", label: "ENG" },
  { code: "RU", label: "РУС" },
]

export function Header() {
  const [activeLang, setActiveLang] = useState("GE")

  return (
    <header className="sticky top-0 z-50 w-full bg-background/80 backdrop-blur-md border-b border-border/50">
      <div className="container mx-auto flex h-16 items-center justify-between px-4 md:px-6">
        <div className="flex items-center gap-2">
          <div className="flex items-center gap-1">
            <div className="h-8 w-8 rounded-full bg-primary flex items-center justify-center">
              <span className="text-primary-foreground font-bold text-sm">F</span>
            </div>
            <span className="text-xl font-semibold tracking-tight text-foreground">
              Femibion
            </span>
          </div>
        </div>

        <nav className="flex items-center gap-1 rounded-full bg-secondary p-1">
          {languages.map((lang) => (
            <button
              key={lang.code}
              onClick={() => setActiveLang(lang.code)}
              className={cn(
                "px-3 py-1.5 text-sm font-medium rounded-full transition-all duration-200",
                activeLang === lang.code
                  ? "bg-primary text-primary-foreground shadow-sm"
                  : "text-muted-foreground hover:text-foreground"
              )}
            >
              {lang.code}
            </button>
          ))}
        </nav>
      </div>
    </header>
  )
}
