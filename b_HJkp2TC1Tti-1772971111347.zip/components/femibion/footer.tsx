import { Facebook, Instagram, MapPin, Phone, Mail, Shield, Award } from "lucide-react"

export function Footer() {
  return (
    <footer className="bg-foreground text-background py-12 md:py-16">
      <div className="container mx-auto px-4 md:px-6">
        <div className="grid gap-10 md:grid-cols-2 lg:grid-cols-4">
          <div>
            <div className="flex items-center gap-2 mb-4">
              <div className="h-10 w-10 rounded-full bg-primary flex items-center justify-center">
                <span className="text-primary-foreground font-bold text-lg">F</span>
              </div>
              <span className="text-2xl font-semibold">Femibion</span>
            </div>
            <p className="text-background/70 leading-relaxed">
              #1 პრენატალური ვიტამინი ევროპაში. ზრუნვა დედისა და ბავშვის ჯანმრთელობაზე.
            </p>
          </div>

          <div>
            <h3 className="font-semibold text-lg mb-4">კონტაქტი</h3>
            <ul className="space-y-3">
              <li className="flex items-center gap-3 text-background/70">
                <MapPin className="h-5 w-5 shrink-0" />
                <span>თბილისი, საქართველო</span>
              </li>
              <li className="flex items-center gap-3 text-background/70">
                <Phone className="h-5 w-5 shrink-0" />
                <span>+995 32 XXX XX XX</span>
              </li>
              <li className="flex items-center gap-3 text-background/70">
                <Mail className="h-5 w-5 shrink-0" />
                <span>info@femibion.ge</span>
              </li>
            </ul>
          </div>

          <div>
            <h3 className="font-semibold text-lg mb-4">სოციალური</h3>
            <div className="flex gap-3">
              <a
                href="#"
                className="h-12 w-12 rounded-full bg-background/10 flex items-center justify-center transition-colors hover:bg-primary"
                aria-label="Facebook"
              >
                <Facebook className="h-5 w-5" />
              </a>
              <a
                href="#"
                className="h-12 w-12 rounded-full bg-background/10 flex items-center justify-center transition-colors hover:bg-primary"
                aria-label="Instagram"
              >
                <Instagram className="h-5 w-5" />
              </a>
            </div>
          </div>

          <div>
            <h3 className="font-semibold text-lg mb-4">სერტიფიკატები</h3>
            <div className="flex gap-4">
              <div className="h-14 w-14 rounded-xl bg-background/10 flex items-center justify-center">
                <Shield className="h-7 w-7 text-primary" />
              </div>
              <div className="h-14 w-14 rounded-xl bg-background/10 flex items-center justify-center">
                <Award className="h-7 w-7 text-primary" />
              </div>
            </div>
            <p className="text-sm text-background/50 mt-3">
              სამედიცინო სერტიფიცირებული პროდუქტი
            </p>
          </div>
        </div>

        <div className="border-t border-background/10 mt-10 pt-8 text-center text-sm text-background/50">
          <p>© 2026 Femibion Georgia. ყველა უფლება დაცულია.</p>
        </div>
      </div>
    </footer>
  )
}
