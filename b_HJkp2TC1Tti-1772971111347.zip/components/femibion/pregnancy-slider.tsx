"use client"

import { useState } from "react"
import { cn } from "@/lib/utils"

const stages = [
  { week: 0, label: "დაგეგმვა", product: 1 },
  { week: 4, label: "4 კვირა", product: 1 },
  { week: 8, label: "8 კვირა", product: 1 },
  { week: 12, label: "12 კვირა", product: 1 },
  { week: 13, label: "13 კვირა", product: 2 },
  { week: 20, label: "20 კვირა", product: 2 },
  { week: 28, label: "28 კვირა", product: 2 },
  { week: 36, label: "36 კვირა", product: 2 },
  { week: 40, label: "მშობიარობა", product: 2 },
  { week: 44, label: "ლაქტაცია", product: 2 },
]

export function PregnancySlider() {
  const [selectedWeek, setSelectedWeek] = useState(8)

  const currentStage = stages.reduce((prev, curr) => {
    if (curr.week <= selectedWeek) return curr
    return prev
  }, stages[0])

  const recommendedProduct = currentStage.product

  return (
    <section className="py-16 md:py-24 bg-secondary/50">
      <div className="container mx-auto px-4 md:px-6">
        <div className="text-center mb-12">
          <h2 className="text-3xl font-bold tracking-tight text-foreground sm:text-4xl mb-4 text-balance">
            რომელ კვირაზე ხარ?
          </h2>
          <p className="text-lg text-muted-foreground">
            აირჩიე შენი ეტაპი და გაიგე რომელი პროდუქტია შენთვის
          </p>
        </div>

        <div className="max-w-3xl mx-auto">
          <div className="bg-card rounded-3xl p-6 md:p-10 shadow-xl border border-border">
            <div className="mb-8">
              <div className="flex justify-between items-center mb-4">
                <span className="text-sm font-medium text-muted-foreground">დაგეგმვა</span>
                <span className="text-sm font-medium text-muted-foreground">ლაქტაცია</span>
              </div>

              <div className="relative">
                <div className="absolute inset-0 flex items-center">
                  <div className="w-full h-3 rounded-full bg-gradient-to-r from-pink-200 via-rose-300 to-pink-400" />
                </div>

                <input
                  type="range"
                  min="0"
                  max="44"
                  value={selectedWeek}
                  onChange={(e) => setSelectedWeek(Number(e.target.value))}
                  className="relative w-full h-3 appearance-none bg-transparent cursor-pointer z-10 [&::-webkit-slider-thumb]:appearance-none [&::-webkit-slider-thumb]:h-7 [&::-webkit-slider-thumb]:w-7 [&::-webkit-slider-thumb]:rounded-full [&::-webkit-slider-thumb]:bg-primary [&::-webkit-slider-thumb]:shadow-lg [&::-webkit-slider-thumb]:border-4 [&::-webkit-slider-thumb]:border-white [&::-webkit-slider-thumb]:cursor-grab [&::-webkit-slider-thumb]:transition-transform [&::-webkit-slider-thumb]:hover:scale-110 [&::-moz-range-thumb]:h-7 [&::-moz-range-thumb]:w-7 [&::-moz-range-thumb]:rounded-full [&::-moz-range-thumb]:bg-primary [&::-moz-range-thumb]:shadow-lg [&::-moz-range-thumb]:border-4 [&::-moz-range-thumb]:border-white [&::-moz-range-thumb]:cursor-grab"
                />

                <div className="absolute top-1/2 -translate-y-1/2 left-0 w-full flex justify-between px-1 pointer-events-none">
                  <div className="h-2 w-0.5 bg-white/50 rounded-full" />
                  <div className="h-2 w-0.5 bg-white/50 rounded-full" />
                  <div className="h-2 w-0.5 bg-white/50 rounded-full" />
                  <div className="h-2 w-0.5 bg-white/50 rounded-full" />
                  <div className="h-2 w-0.5 bg-white/50 rounded-full" />
                </div>
              </div>

              <div className="flex justify-center mt-4">
                <div className="inline-flex items-center gap-2 rounded-full bg-primary/10 px-4 py-2">
                  <span className="text-2xl font-bold text-primary">
                    {currentStage.label}
                  </span>
                </div>
              </div>
            </div>

            <div className="border-t border-border pt-8">
              <div className="text-center">
                <p className="text-sm text-muted-foreground mb-2">შენთვის რეკომენდებულია:</p>
                <div className="flex items-center justify-center gap-4">
                  <div
                    className={cn(
                      "flex-1 max-w-[200px] rounded-2xl p-4 border-2 transition-all duration-300",
                      recommendedProduct === 1
                        ? "border-primary bg-primary/5 shadow-lg scale-105"
                        : "border-border opacity-50"
                    )}
                  >
                    <h3 className="font-bold text-foreground">Femibion 1</h3>
                    <p className="text-xs text-muted-foreground">დაგეგმვა & I ტრიმესტრი</p>
                  </div>
                  <div
                    className={cn(
                      "flex-1 max-w-[200px] rounded-2xl p-4 border-2 transition-all duration-300",
                      recommendedProduct === 2
                        ? "border-primary bg-primary/5 shadow-lg scale-105"
                        : "border-border opacity-50"
                    )}
                  >
                    <h3 className="font-bold text-foreground">Femibion 2</h3>
                    <p className="text-xs text-muted-foreground">II-III & ლაქტაცია</p>
                  </div>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>
    </section>
  )
}
