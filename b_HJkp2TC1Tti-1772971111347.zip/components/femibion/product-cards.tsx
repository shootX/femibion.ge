import Image from "next/image"
import { Leaf, Heart, Baby, Droplets } from "lucide-react"

const products = [
  {
    id: 1,
    name: "Femibion 1",
    subtitle: "დაგეგმვა & I ტრიმესტრი",
    description: "ოპტიმალური ფორმულა ორსულობის დაგეგმვისა და პირველი ტრიმესტრისთვის. შეიცავს Metafolin® - ფოლიუმის მჟავას აქტიურ ფორმას.",
    image: "/images/femibion-1.jpg",
    features: [
      { icon: Leaf, label: "Metafolin®" },
      { icon: Heart, label: "ფოლატი 800მკგ" },
    ],
    color: "from-pink-50 to-rose-50",
    borderColor: "border-pink-200",
  },
  {
    id: 2,
    name: "Femibion 2",
    subtitle: "II-III ტრიმესტრი & ლაქტაცია",
    description: "გაფართოებული ფორმულა მეორე და მესამე ტრიმესტრისთვის. DHA ომეგა-3 ბავშვის ტვინის განვითარებისთვის.",
    image: "/images/femibion-2.jpg",
    features: [
      { icon: Baby, label: "DHA Omega-3" },
      { icon: Droplets, label: "200მგ DHA" },
    ],
    color: "from-rose-50 to-pink-100",
    borderColor: "border-rose-200",
  },
]

export function ProductCards() {
  return (
    <section id="products" className="py-16 md:py-24 bg-background">
      <div className="container mx-auto px-4 md:px-6">
        <div className="text-center mb-12 md:mb-16">
          <h2 className="text-3xl font-bold tracking-tight text-foreground sm:text-4xl mb-4 text-balance">
            აირჩიე შენთვის სწორი პროდუქტი
          </h2>
          <p className="text-lg text-muted-foreground max-w-2xl mx-auto">
            ორსულობის თითოეული ეტაპისთვის სპეციალურად შემუშავებული ფორმულა
          </p>
        </div>

        <div className="grid gap-6 md:grid-cols-2 max-w-5xl mx-auto">
          {products.map((product) => (
            <div
              key={product.id}
              className={`group relative overflow-hidden rounded-3xl border-2 ${product.borderColor} bg-gradient-to-br ${product.color} p-6 md:p-8 transition-all duration-300 hover:shadow-xl hover:-translate-y-1`}
            >
              <div className="flex flex-col h-full">
                <div className="relative aspect-[4/3] mb-6 rounded-2xl overflow-hidden bg-white shadow-lg">
                  <Image
                    src={product.image}
                    alt={product.name}
                    fill
                    className="object-cover transition-transform duration-500 group-hover:scale-105"
                  />
                </div>

                <div className="flex-1">
                  <div className="mb-4">
                    <span className="inline-block rounded-full bg-primary/10 px-3 py-1 text-xs font-medium text-primary mb-2">
                      {product.subtitle}
                    </span>
                    <h3 className="text-2xl font-bold text-foreground mb-2">
                      {product.name}
                    </h3>
                    <p className="text-muted-foreground leading-relaxed">
                      {product.description}
                    </p>
                  </div>

                  <div className="flex flex-wrap gap-3 mb-6">
                    {product.features.map((feature, index) => (
                      <div
                        key={index}
                        className="flex items-center gap-2 rounded-full bg-white/80 px-4 py-2 shadow-sm"
                      >
                        <feature.icon className="h-4 w-4 text-primary" />
                        <span className="text-sm font-medium text-foreground">
                          {feature.label}
                        </span>
                      </div>
                    ))}
                  </div>

                  <a
                    href="#order"
                    className="inline-flex w-full h-12 items-center justify-center rounded-full bg-primary text-primary-foreground font-semibold shadow-lg shadow-primary/20 transition-all hover:bg-primary/90 hover:shadow-xl"
                  >
                    შეკვეთა
                  </a>
                </div>
              </div>
            </div>
          ))}
        </div>
      </div>
    </section>
  )
}
