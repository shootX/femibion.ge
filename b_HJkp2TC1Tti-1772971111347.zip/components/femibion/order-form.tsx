"use client"

import { useState } from "react"
import { User, Phone, MapPin, Package, CheckCircle } from "lucide-react"

export function OrderForm() {
  const [formData, setFormData] = useState({
    name: "",
    phone: "",
    address: "",
    product: "",
  })
  const [isSubmitted, setIsSubmitted] = useState(false)

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault()
    setIsSubmitted(true)
  }

  if (isSubmitted) {
    return (
      <section id="order" className="py-16 md:py-24 bg-background">
        <div className="container mx-auto px-4 md:px-6">
          <div className="max-w-lg mx-auto text-center">
            <div className="rounded-3xl bg-card border border-border p-8 md:p-12 shadow-xl">
              <div className="mb-6 inline-flex h-20 w-20 items-center justify-center rounded-full bg-green-100">
                <CheckCircle className="h-10 w-10 text-green-600" />
              </div>
              <h2 className="text-2xl font-bold text-foreground mb-4">
                მადლობა შეკვეთისთვის!
              </h2>
              <p className="text-muted-foreground mb-6">
                თქვენი შეკვეთა მიღებულია. ჩვენი ოპერატორი დაგიკავშირდებათ უახლოეს დროში.
              </p>
              <button
                onClick={() => setIsSubmitted(false)}
                className="inline-flex h-12 items-center justify-center rounded-full bg-primary px-8 font-semibold text-primary-foreground transition-all hover:bg-primary/90"
              >
                ახალი შეკვეთა
              </button>
            </div>
          </div>
        </div>
      </section>
    )
  }

  return (
    <section id="order" className="py-16 md:py-24 bg-background">
      <div className="container mx-auto px-4 md:px-6">
        <div className="text-center mb-12">
          <h2 className="text-3xl font-bold tracking-tight text-foreground sm:text-4xl mb-4 text-balance">
            შეუკვეთე ახლავე
          </h2>
          <p className="text-lg text-muted-foreground max-w-xl mx-auto">
            შეავსე ფორმა და მიიღე პროდუქტი პირდაპირ სახლში
          </p>
        </div>

        <div className="max-w-lg mx-auto">
          <form
            onSubmit={handleSubmit}
            className="rounded-3xl bg-card border border-border p-6 md:p-10 shadow-xl"
          >
            <div className="space-y-6">
              <div>
                <label
                  htmlFor="name"
                  className="block text-sm font-medium text-foreground mb-2"
                >
                  სახელი და გვარი
                </label>
                <div className="relative">
                  <User className="absolute left-4 top-1/2 -translate-y-1/2 h-5 w-5 text-muted-foreground" />
                  <input
                    type="text"
                    id="name"
                    required
                    value={formData.name}
                    onChange={(e) =>
                      setFormData({ ...formData, name: e.target.value })
                    }
                    placeholder="მარიამ ბერიძე"
                    className="w-full h-14 rounded-2xl border border-input bg-input pl-12 pr-4 text-foreground placeholder:text-muted-foreground focus:outline-none focus:ring-2 focus:ring-primary focus:border-transparent transition-all"
                  />
                </div>
              </div>

              <div>
                <label
                  htmlFor="phone"
                  className="block text-sm font-medium text-foreground mb-2"
                >
                  ტელეფონის ნომერი
                </label>
                <div className="relative">
                  <Phone className="absolute left-4 top-1/2 -translate-y-1/2 h-5 w-5 text-muted-foreground" />
                  <div className="absolute left-12 top-1/2 -translate-y-1/2 text-muted-foreground font-medium">
                    +995
                  </div>
                  <input
                    type="tel"
                    id="phone"
                    required
                    value={formData.phone}
                    onChange={(e) =>
                      setFormData({ ...formData, phone: e.target.value })
                    }
                    placeholder="5XX XXX XXX"
                    className="w-full h-14 rounded-2xl border border-input bg-input pl-24 pr-4 text-foreground placeholder:text-muted-foreground focus:outline-none focus:ring-2 focus:ring-primary focus:border-transparent transition-all"
                  />
                </div>
              </div>

              <div>
                <label
                  htmlFor="address"
                  className="block text-sm font-medium text-foreground mb-2"
                >
                  მიწოდების მისამართი
                </label>
                <div className="relative">
                  <MapPin className="absolute left-4 top-4 h-5 w-5 text-muted-foreground" />
                  <textarea
                    id="address"
                    required
                    value={formData.address}
                    onChange={(e) =>
                      setFormData({ ...formData, address: e.target.value })
                    }
                    placeholder="თბილისი, ჭავჭავაძის გამზ. 12"
                    rows={3}
                    className="w-full rounded-2xl border border-input bg-input pl-12 pr-4 py-4 text-foreground placeholder:text-muted-foreground focus:outline-none focus:ring-2 focus:ring-primary focus:border-transparent transition-all resize-none"
                  />
                </div>
              </div>

              <div>
                <label
                  htmlFor="product"
                  className="block text-sm font-medium text-foreground mb-2"
                >
                  აირჩიე პროდუქტი
                </label>
                <div className="relative">
                  <Package className="absolute left-4 top-1/2 -translate-y-1/2 h-5 w-5 text-muted-foreground" />
                  <select
                    id="product"
                    required
                    value={formData.product}
                    onChange={(e) =>
                      setFormData({ ...formData, product: e.target.value })
                    }
                    className="w-full h-14 rounded-2xl border border-input bg-input pl-12 pr-4 text-foreground focus:outline-none focus:ring-2 focus:ring-primary focus:border-transparent transition-all appearance-none cursor-pointer"
                  >
                    <option value="">აირჩიე პროდუქტი</option>
                    <option value="femibion-1">Femibion 1 - დაგეგმვა & I ტრიმესტრი</option>
                    <option value="femibion-2">Femibion 2 - II-III ტრიმესტრი & ლაქტაცია</option>
                  </select>
                  <div className="absolute right-4 top-1/2 -translate-y-1/2 pointer-events-none">
                    <svg
                      className="h-5 w-5 text-muted-foreground"
                      fill="none"
                      stroke="currentColor"
                      viewBox="0 0 24 24"
                    >
                      <path
                        strokeLinecap="round"
                        strokeLinejoin="round"
                        strokeWidth={2}
                        d="M19 9l-7 7-7-7"
                      />
                    </svg>
                  </div>
                </div>
              </div>

              <button
                type="submit"
                className="w-full h-14 rounded-2xl bg-primary text-primary-foreground font-bold text-lg shadow-lg shadow-primary/25 transition-all hover:bg-primary/90 hover:shadow-xl hover:shadow-primary/30 hover:-translate-y-0.5 active:translate-y-0"
              >
                შეკვეთის დადასტურება
              </button>

              <p className="text-center text-xs text-muted-foreground">
                შეკვეთის გაფორმებით თქვენ ეთანხმებით ჩვენს პირობებს
              </p>
            </div>
          </form>
        </div>
      </div>
    </section>
  )
}
